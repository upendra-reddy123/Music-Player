# Music-Player-Using-Tkinter
## This Tkinter(Python GUI) application allows the users to play music by selecting an mp4 file from their local system. It also lets the user to pause, forward, queue songs or play a playlist. .
## Download the music_player.exe file to use the application.
